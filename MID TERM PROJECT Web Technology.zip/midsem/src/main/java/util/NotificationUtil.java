package util;

public class NotificationUtil {

	public static final String TYPE_SUCCESS = "bg-teal-500";
	public static final String TYPE_INFO = "bg-blue-500";
	public static final String TYPE_WARNING = "bg-yellow-500";
	public static final String TYPE_DANGER = "bg-red-500";

	public static String getColor(String type) {

		type = type.toLowerCase();

		return type.equals(TYPE_SUCCESS) ? TYPE_SUCCESS
				: (type.equals(TYPE_WARNING) ? TYPE_WARNING : (type.equals(TYPE_DANGER) ? TYPE_DANGER : TYPE_INFO));
	}
}
