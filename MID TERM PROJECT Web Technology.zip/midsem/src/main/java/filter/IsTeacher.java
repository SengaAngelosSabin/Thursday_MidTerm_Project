package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.Auth;

/**
 * Servlet Filter implementation class IsTeacher
 */
public class IsTeacher extends HttpFilter implements Filter {
	private static final long serialVersionUID = 1L;

	public IsTeacher() {
		super();
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		
		// check if user has a role of teacher
		if (Auth.guard("teacher", req) || Auth.guard("admin", req)) {
			chain.doFilter(request, response);
		} else {
			res.sendRedirect("/error?403=true");
		}
	}

}
