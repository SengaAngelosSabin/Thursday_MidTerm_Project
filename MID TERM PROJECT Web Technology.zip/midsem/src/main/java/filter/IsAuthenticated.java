package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.Auth;

public class IsAuthenticated extends HttpFilter implements Filter {
	private static final long serialVersionUID = 1L;

    public IsAuthenticated() {
        super();
    }

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		
		// check if authenticated
		if(Auth.check(req)) {
			chain.doFilter(request, response);
		}else {
			res.sendRedirect("/login");
		}
	}

}
