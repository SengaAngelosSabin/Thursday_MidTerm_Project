package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CourseDao;
import model.Course;
import util.HtmlUtil;
import util.NotificationUtil;

@WebServlet(name = "CoursesController", urlPatterns = "/admin-courses")
public class CoursesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		super.service(req, resp);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("create") != null) {

			renderCreate(request, response);

		} else if (request.getParameter("edit") != null) {

			renderEdit(request, response);

		} else {

			renderIndex(request, response);

		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("update") != null) {

			doPut(request, response);

		} else if (request.getParameter("delete") != null) {

			doDelete(request, response);

		} else {

			// create a new course
			Course course = new Course(request.getParameter("code"), request.getParameter("name"),
					request.getParameter("description"), Integer.parseInt(request.getParameter("credits")));

			CourseDao courseDao = new CourseDao();
			courseDao.save(course);

			request.setAttribute("success", "Course created successfully");
			doGet(request, response);

		}

	}

	private void renderIndex(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		CourseDao courseDao = new CourseDao();
		List<Course> courseList = courseDao.getAll();

		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Courses"));

		// Session flash notification - if any
		if (request.getAttribute("success") != null) {
			out.println(HtmlUtil.getNotificationDiv((String) request.getAttribute("success"),
					NotificationUtil.TYPE_SUCCESS));
		}

		// OUPUT THE CONTENT
		// Render create button
		out.println(HtmlUtil.getCreateButton("/admin-courses?create=1", "New course"));

		String[] headers = { "course code", "course name", "credits", "teacher names" };
		out.println(HtmlUtil.getTableHeader(headers));

		for (Course course : courseList) {

			String[] tableData = { course.getCode(), course.getName(), String.valueOf(course.getCredits()),
					course.getTeacherNames() };
			String editUrl = "/admin-courses?edit=1&id=" + course.getId();
			String deleteUrl = "/admin-courses?delete=1&id=" + course.getId();

			out.print(HtmlUtil.getTableRow(tableData, editUrl, deleteUrl));
		}

		out.println(HtmlUtil.getTableFooter());

		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderCreate(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("courses"));

		// OUPUT THE CONTENT
		// Render create au form
		String formHeader = HtmlUtil.getFormHeader("Add New course", "/admin-courses");
		out.println(formHeader);

		// Render form inputs
		out.println(HtmlUtil.getFormInput("text", "Course code:", "code", null));
		out.println(HtmlUtil.getFormInput("text", "Course name:", "name", null));
		out.println(HtmlUtil.getFormTextarea("Course description:", "description", null));
		out.println(HtmlUtil.getFormInput("number", "Credits:", "credits", null));
		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Create"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderEdit(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Find the au
		CourseDao courseDao = new CourseDao();
		Course course = courseDao.getById(Integer.parseInt(request.getParameter("id")));

		if (course == null) {
			out.println("404 page");
			return;
		}

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("courses"));

		// OUPUT THE CONTENT
		// Render create form
		String formHeader = HtmlUtil.getFormHeader("Edit course", "/admin-courses?update=1&id=" + course.getId());
		out.println(formHeader);

		// Render form inputs
		out.println(HtmlUtil.getFormInput("text", "Course code:", "code", course.getCode()));
		out.println(HtmlUtil.getFormInput("text", "Course name:", "name", course.getName()));
		out.println(HtmlUtil.getFormTextarea("Course description:", "description", course.getDescription()));
		out.println(HtmlUtil.getFormInput("number", "Credits:", "credits", String.valueOf(course.getCredits())));
		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Update"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the course
		CourseDao courseDao = new CourseDao();
		Course course = courseDao.getById(Integer.parseInt(request.getParameter("id")));

		if (course == null) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("404 page");
			out.close();
			return;
		}

		course.setCode(request.getParameter("code"));
		course.setName(request.getParameter("name"));
		course.setDescription(request.getParameter("description"));
		course.setCredits(Integer.parseInt(request.getParameter("credits")));

		courseDao.save(course);

		request.setAttribute("success", "Course updated successfully");
		doGet(request, response);

	}

	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the course
		CourseDao courseDao = new CourseDao();
		Course course = courseDao.getById(Integer.parseInt(request.getParameter("id")));

		if (course == null) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("404 page");
			out.close();
			return;
		}

		courseDao.delete(course.getId());

		request.setAttribute("success", "Course deleted successfully");
		doGet(request, response);

	}

}
