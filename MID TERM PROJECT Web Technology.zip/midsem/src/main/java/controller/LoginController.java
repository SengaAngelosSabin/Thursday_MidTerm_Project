package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.Auth;
import dao.UserDao;
import model.User;
import util.HtmlUtil;

@WebServlet(name = "LoginController", urlPatterns = "/login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println(HtmlUtil.getLoginHeader());

		if (request.getAttribute("errors") != null) {
			out.println(HtmlUtil.getValidationErrorDiv((List<String>) request.getAttribute("errors")));
		}

		out.println(HtmlUtil.getLoginFooter());
		out.close();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1.validate
		UserDao userDao = new UserDao();
		User user = userDao.getByEmail(request.getParameter("email"));
		
		List<String> errors = validateUserInput(request, user);

		// 3.if validation errors,
		if (errors.size() > 0) {
			request.setAttribute("errors", errors);
			doGet(request, response);
			return;
		}

		// 4.else,

		// 5.log them in
		Auth.login(user, request);
		Auth.redirect(user, request, response);
		
//		response.sendRedirect("/");
		
	}

	
	private List<String> validateUserInput(HttpServletRequest request, User dbUser) {

		List<String> errors = new ArrayList<>();

		if ( dbUser == null) {

			errors.add("user email address doesn't exist");

		} else if (!dbUser.getPassword().equals(request.getParameter("password"))) {

			errors.add("Invalid password");
		}

		return errors;
	}

	
}
