package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AUDao;
import dao.StudentDao;
import model.AcademicUnit;
import model.Student;
import util.HtmlUtil;
import util.NotificationUtil;

@WebServlet(name = "StudentsController", urlPatterns = "/admin-students")
public class StudentsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		super.service(req, resp);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("create") != null) {

			renderCreate(request, response);

		} else if (request.getParameter("edit") != null) {

			renderEdit(request, response);

		} else {

			renderIndex(request, response);

		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("update") != null) {

			doPut(request, response);

		} else if (request.getParameter("delete") != null) {

			doDelete(request, response);

		} else {

			// format date
			LocalDate dob = LocalDate.parse(request.getParameter("dob"), DateTimeFormatter.ISO_DATE);

			// create a new Student
			Student student = new Student(request.getParameter("student_id"), request.getParameter("names"), dob);

			// attach au
			AUDao auDao = new AUDao();
			AcademicUnit academicUnit = auDao.getById(Integer.parseInt(request.getParameter("academicUnit_id")));
			student.setAcademicUnit(academicUnit);

			// persist student
			StudentDao studentdao = new StudentDao();
			studentdao.save(student);

			request.setAttribute("success", "Student created successfully");
			doGet(request, response);

		}

	}

	private void renderIndex(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		StudentDao studentDao = new StudentDao();
		List<Student> studentList = studentDao.getAll();

		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Students"));

		// Session flash notification - if any
		if (request.getAttribute("success") != null) {
			out.println(HtmlUtil.getNotificationDiv((String) request.getAttribute("success"),
					NotificationUtil.TYPE_SUCCESS));
		}

		// OUPUT THE CONTENT
		// Render create button
		out.println(HtmlUtil.getCreateButton("/admin-students?create=1", "New Student"));

		String[] headers = { "Reg number", "Student names", "Academic Unit" };
		out.println(HtmlUtil.getTableHeader(headers));

		for (Student student : studentList) {

			String[] tableData = { student.getRegNo(), student.getStudentNames(), student.getAcademicUnit().getName() };
			String editUrl = "/admin-students?edit=1&id=" + student.getId();
			String deleteUrl = "/admin-students?delete=1&id=" + student.getId();

			out.print(HtmlUtil.getTableRow(tableData, editUrl, deleteUrl));
		}

		out.println(HtmlUtil.getTableFooter());

		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderCreate(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Students"));

		// OUPUT THE CONTENT
		// Render create au form
		String formHeader = HtmlUtil.getFormHeader("Add New Student", "/admin-students");
		out.println(formHeader);

		// Render form inputs
		out.println(HtmlUtil.getFormInput("text", "Student Id:", "student_id", null));
		out.println(HtmlUtil.getFormInput("text", "Student names:", "names", null));
		out.println(HtmlUtil.getFormSelectFromList("Academic unit:", "academicUnit_id", AcademicUnit.getSelectOptions(),
				null));
		out.println(HtmlUtil.getFormInput("date", "Date of birth:", "dob", null));
		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Create"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderEdit(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Find the au
		StudentDao studentDao = new StudentDao();
		Student student = studentDao.getById(Integer.parseInt(request.getParameter("id")));

		if (student == null) {
			out.println("404 page");
			return;
		}

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Students"));

		// OUPUT THE CONTENT
		// Render create au form
		String formHeader = HtmlUtil.getFormHeader("Edit Student", "/admin-students?update=1&id=" + student.getId());
		out.println(formHeader);

		// Render form inputs
		out.println(HtmlUtil.getFormInput("text", "Student Id:", "student_id", student.getRegNo()));
		out.println(HtmlUtil.getFormInput("text", "Student names:", "names", student.getStudentNames()));
		out.println(HtmlUtil.getFormSelectFromList("Academic unit:", "academicUnit_id", AcademicUnit.getSelectOptions(),
				String.valueOf(student.getAcademicUnit().getId())));
		out.println(HtmlUtil.getFormInput("date", "Date of birth:", "dob", student.getDateOfBirth().toString()));
		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Update"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the student
		StudentDao studentDao = new StudentDao();
		Student student = studentDao.getById(Integer.parseInt(request.getParameter("id")));

		if (student == null) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("404 page");
			out.close();
			return;
		}

		// Update the student

		LocalDate dob = LocalDate.parse(request.getParameter("dob"), DateTimeFormatter.ISO_DATE);

		student.setAcademicUnit(null);
		student.setRegNo(request.getParameter("student_id"));
		student.setStudentNames(request.getParameter("names"));
		student.setDateOfBirth(dob);

		studentDao.save(student);

		request.setAttribute("success", "Student updated successfully");
		doGet(request, response);

	}

	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the student
		StudentDao studentDao = new StudentDao();
		Student student = studentDao.getById(Integer.parseInt(request.getParameter("id")));

		if (student == null) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("404 page");
			out.close();
			return;
		}

		student.setAcademicUnit(null);
		studentDao.delete(student.getId());

		request.setAttribute("success", "Student deleted successfully");
		doGet(request, response);

	}

}
