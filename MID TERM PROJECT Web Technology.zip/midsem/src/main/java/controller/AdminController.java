package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.HtmlUtil;

@WebServlet(name = "AdminController", urlPatterns = "/admin-home")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		super.service(req, resp);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		renderIndex(request, response);

	}

	private void renderIndex(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Java Servlet CRUD - HTML and CSS"));

		out.println(HtmlUtil.getFooter());

		out.close();
	}

}
