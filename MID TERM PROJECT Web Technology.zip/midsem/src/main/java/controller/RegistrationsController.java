package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CourseDao;
import dao.RegistrationDao;
import dao.SemesterDao;
import dao.StudentDao;
import model.Course;
import model.Registration;
import model.Semester;
import model.Student;
import util.HtmlUtil;
import util.NotificationUtil;

@WebServlet(name = "RegistrationsController", urlPatterns = "/admin-registrations")
public class RegistrationsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		super.service(req, resp);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("create") != null) {

			renderCreate(request, response);

		} else if (request.getParameter("edit") != null) {

			renderEdit(request, response);

		} else {

			renderIndex(request, response);

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("update") != null) {

			doPut(request, response);

		} else if (request.getParameter("delete") != null) {

			doDelete(request, response);

		} else {

			// get today's date
			String dateString = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
			LocalDate registrationDate = LocalDate.parse(dateString, DateTimeFormatter.ISO_DATE);

			Registration registration = new Registration(registrationDate);

			// attach student
			StudentDao studentDao = new StudentDao();
			Student student = studentDao.getByRegNo(request.getParameter("student_id"));

			if (student == null) {
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.println("404 page - student not found");
				return;
			}

			registration.setStudent(student);

			// attach semester
			SemesterDao semesterDao = new SemesterDao();
			Semester semester = semesterDao.getById(Integer.parseInt(request.getParameter("semester")));
			registration.setSemester(semester);

			// attach courses
			CourseDao courseDao = new CourseDao();
			String[] courses = request.getParameterValues("courses");

			if (courses == null || courses.length == 0) {
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.println("500 page - must add courses");
				return;
			}

			for (String courseId : courses) {
				Course course = courseDao.getById(Integer.parseInt(courseId));
				registration.addCourse(course);
			}

			RegistrationDao registrationDao = new RegistrationDao();
			registrationDao.save(registration);

			request.setAttribute("success", "Registration created successfully");
			doGet(request, response);
		}

	}

	private void renderIndex(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		RegistrationDao registrationDao = new RegistrationDao();
		List<Registration> registrationList = registrationDao.getAll();

		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Registrations"));

		// Session flash notification - if any
		if (request.getAttribute("success") != null) {
			out.println(HtmlUtil.getNotificationDiv((String) request.getAttribute("success"),
					NotificationUtil.TYPE_SUCCESS));
		}

		// OUPUT THE CONTENT
		// Render create button
		out.println(HtmlUtil.getCreateButton("/admin-registrations?create=1", "New Registration"));

		String[] headers = { "Student Id", "Registration date" };
		out.println(HtmlUtil.getTableHeader(headers));

		for (Registration registration : registrationList) {

			String[] tableData = { String.valueOf(registration.getStudent().getId()),
					HtmlUtil.formatDate(registration.getRegistrationDate()) };
			String editUrl = "/admin-registrations?edit=1&id=" + registration.getId();
			String deleteUrl = "/admin-registrations?delete=1&id=" + registration.getId();

			out.print(HtmlUtil.getTableRow(tableData, editUrl, deleteUrl));
		}

		out.println(HtmlUtil.getTableFooter());

		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderCreate(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		CourseDao courseDao = new CourseDao();
		List<Course> courses = courseDao.getAll();

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Registrations"));

		// OUPUT THE CONTENT
		// Render create au form
		String formHeader = HtmlUtil.getFormHeader("Add New registration", "/admin-registrations");
		out.println(formHeader);

		// Render form inputs
		out.println(HtmlUtil.getFormInput("text", "Student Id:", "student_id", null));
		out.println(HtmlUtil.getFormSelectFromList("Semester:", "semester", Semester.getSelectOptions(), null));
		out.println(HtmlUtil.getFormFieldset("Add courses", "courses", Course.toFieldSetInputs(courses), null));

		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Save Registration"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderEdit(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Find the au
		RegistrationDao registrationDao = new RegistrationDao();
		Registration registration = registrationDao.getById(Integer.parseInt(request.getParameter("id")));

		if (registration == null) {
			out.println("404 page");
			return;
		}

		CourseDao courseDao = new CourseDao();
		List<Course> courses = courseDao.getAll();

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Registrations"));

		// OUPUT THE CONTENT
		// Render create form
		String formHeader = HtmlUtil.getFormHeader("Edit registration",
				"/admin-registrations?update=1&id=" + registration.getId());
		out.println(formHeader);

		// Render form inputs
//		out.println(HtmlUtil.getFormInput("text", "Student Id:", "student_id", String.valueOf(registration.getStudent().getId())));
		out.println(HtmlUtil.getInfoDiv("Student Id:", registration.getStudent().getRegNo()));
		out.println(HtmlUtil.getInfoDiv("Student Names:", registration.getStudent().getStudentNames()));
//		out.println(HtmlUtil.getFormSelectFromList("Semester:", "semester", Semester.getSelectOptions(), registration.getSemester().getName()));
		out.println(HtmlUtil.getFormFieldset("Add courses", "courses", Course.toFieldSetInputs(courses),
				registration.getStudentCourseIds()));

		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Update"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the registration
		RegistrationDao registrationDao = new RegistrationDao();
		Registration registration = registrationDao.getById(Integer.parseInt(request.getParameter("id")));

		if (registration == null) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("404 page");
			out.close();
			return;
		}

		// get today's date
		String dateString = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		LocalDate registrationDate = LocalDate.parse(dateString, DateTimeFormatter.ISO_DATE);

		registration.setRegistrationDate(registrationDate);
		registration.setCourses(null);

		String[] courses = request.getParameterValues("courses");

		if (courses == null || courses.length == 0) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("500 page - must add courses");
			return;
		}

		CourseDao courseDao = new CourseDao();
		for (String courseId : courses) {
			Course course = courseDao.getById(Integer.parseInt(courseId));
			registration.addCourse(course);
		}

		registrationDao.save(registration);

		request.setAttribute("success", "Registration updated successfully");
		doGet(request, response);

	}

	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the registration
		RegistrationDao registrationDao = new RegistrationDao();
		Registration registration = registrationDao.getById(Integer.parseInt(request.getParameter("id")));

		if (registration == null) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("404 page");
			out.close();
			return;
		}

		registration.setCourses(null);
		registration.setSemester(null);
		registration.setStudent(null);
		registrationDao.delete(registration.getId());

		request.setAttribute("success", "Registration deleted successfully");
		doGet(request, response);
	}

}
