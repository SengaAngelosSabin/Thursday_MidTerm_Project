package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.HtmlUtil;

@WebServlet(name = "ErrorController", urlPatterns = "/error")
public class ErrorController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("403") != null) {

			renderForbidden(request, response);

		} else if (request.getParameter("404") != null) {

			renderNotFound(request, response);

		} else if (request.getParameter("500") != null) {

			renderServerError(request, response);

		}

	}

	private void renderForbidden(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println(HtmlUtil.get403Page());

		out.close();
	}

	private void renderNotFound(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println(HtmlUtil.get404Page());

		out.close();
	}

	private void renderServerError(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println(HtmlUtil.get500Page());

		out.close();
	}

}
