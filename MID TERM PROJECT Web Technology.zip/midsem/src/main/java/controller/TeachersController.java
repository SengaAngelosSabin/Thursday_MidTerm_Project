package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CourseDao;
import dao.TeacherDao;
import model.Course;
import model.Teacher;
import model.TeacherRole;
import util.HtmlUtil;
import util.NotificationUtil;

@WebServlet(name = "TeachersController", urlPatterns = "/admin-teachers")
public class TeachersController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		super.service(req, resp);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("create") != null) {

			renderCreate(request, response);

		} else if (request.getParameter("edit") != null) {

			renderEdit(request, response);

		} else {

			renderIndex(request, response);

		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("update") != null) {

			doPut(request, response);

		} else if (request.getParameter("delete") != null) {

			doDelete(request, response);

		} else {

			// create a new teacher
			Teacher teacher = new Teacher(request.getParameter("name"),
					TeacherRole.valueOf(request.getParameter("role")), request.getParameter("qualification"));

			CourseDao courseDao = new CourseDao();
			String[] courses = request.getParameterValues("courses");

			if (courses == null || courses.length == 0) {
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.println("500 page - must add courses");
				return;
			}

			for (String courseId : courses) {
				Course course = courseDao.getById(Integer.parseInt(courseId));
				teacher.addCourse(course);
			}

			TeacherDao teacherDao = new TeacherDao();
			teacherDao.save(teacher);

			request.setAttribute("success", "Teacher created successfully");
			doGet(request, response);
		}

	}

	private void renderIndex(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		TeacherDao teacherDao = new TeacherDao();
		List<Teacher> teacherList = teacherDao.getAll();

		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Teachers"));

		// Session flash notification - if any
		if (request.getAttribute("success") != null) {
			out.println(HtmlUtil.getNotificationDiv((String) request.getAttribute("success"),
					NotificationUtil.TYPE_SUCCESS));
		}

		// OUPUT THE CONTENT
		// Render create button
		out.println(HtmlUtil.getCreateButton("/admin-teachers?create=1", "New teacher"));

		String[] headers = { "Teacher names", "Qualification", "Assigned courses" };
		out.println(HtmlUtil.getTableHeader(headers));

		for (Teacher teacher : teacherList) {

			String[] tableData = { teacher.getNames(), teacher.getQualification(), teacher.getTeacherCourses() };
			String editUrl = "/admin-teachers?edit=1&id=" + teacher.getId();
			String deleteUrl = "/admin-teachers?delete=1&id=" + teacher.getId();

			out.print(HtmlUtil.getTableRow(tableData, editUrl, deleteUrl));
		}

		out.println(HtmlUtil.getTableFooter());

		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderCreate(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Teachers"));

		// OUPUT THE CONTENT
		// Render create au form
		String formHeader = HtmlUtil.getFormHeader("Add New teacher", "/admin-teachers");
		out.println(formHeader);

		// Render form inputs
		out.println(HtmlUtil.getFormSelect("Teacher Role:", "role", TeacherRole.toStringArray(), null));
		out.println(HtmlUtil.getFormInput("text", "Teacher names:", "name", null));
		String[] qualifications = { "MASTERS", "PHD", "PROFESSOR" };
		out.println(HtmlUtil.getFormSelect("Qualification:", "qualification", qualifications, null));

		CourseDao courseDao = new CourseDao();
		List<Course> courses = courseDao.getAll();

		out.println(HtmlUtil.getFormFieldset("Assign courses", "courses", Course.toFieldSetInputs(courses), null));

		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Create"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderEdit(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Find the au
		TeacherDao teacherDao = new TeacherDao();
		Teacher teacher = teacherDao.getById(Integer.parseInt(request.getParameter("id")));

		if (teacher == null) {
			out.println("404 page");
			return;
		}

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Teachers"));

		// OUPUT THE CONTENT
		// Render create form
		String formHeader = HtmlUtil.getFormHeader("Edit teacher", "/admin-teachers?update=1&id=" + teacher.getId());
		out.println(formHeader);

		// Render form inputs
		out.println(
				HtmlUtil.getFormSelect("Teacher Role:", "role", TeacherRole.toStringArray(), teacher.getRole().name()));
		out.println(HtmlUtil.getFormInput("text", "Teacher names:", "name", teacher.getNames()));
		String[] qualifications = { "MASTERS", "PHD", "PROFESSOR" };
		out.println(
				HtmlUtil.getFormSelect("Qualification:", "qualification", qualifications, teacher.getQualification()));
		CourseDao courseDao = new CourseDao();
		List<Course> courses = courseDao.getAll();
		out.println(HtmlUtil.getFormFieldset("Assign courses", "courses", Course.toFieldSetInputs(courses),
				teacher.getTeacherCourseIds()));

		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Update"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the teacher
		TeacherDao teacherDao = new TeacherDao();
		Teacher teacher = teacherDao.getById(Integer.parseInt(request.getParameter("id")));

		if (teacher == null) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("404 page");
			out.close();
			return;
		}

		teacher.setCourses(null);

		teacher.setNames(request.getParameter("name"));
		teacher.setRole(TeacherRole.valueOf(request.getParameter("role")));
		teacher.setQualification(request.getParameter("qualification"));

		CourseDao courseDao = new CourseDao();
		String[] courses = request.getParameterValues("courses");

		if (courses == null || courses.length == 0) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("500 page - must add courses");
			return;
		}

		for (String courseId : courses) {
			Course course = courseDao.getById(Integer.parseInt(courseId));
			teacher.addCourse(course);
		}

		teacherDao.save(teacher);

		request.setAttribute("success", "Teacher updated successfully");
		doGet(request, response);

	}

	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the teacher
		TeacherDao teacherDao = new TeacherDao();
		Teacher teacher = teacherDao.getById(Integer.parseInt(request.getParameter("id")));

		if (teacher == null) {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("404 page");
			out.close();
			return;
		}

		teacher.setCourses(null);
		teacherDao.delete(teacher.getId());

		request.setAttribute("success", "Teacher deleted successfully");
		doGet(request, response);

	}

}
