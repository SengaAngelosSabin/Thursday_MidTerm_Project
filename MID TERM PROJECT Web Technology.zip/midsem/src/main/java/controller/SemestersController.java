package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.SemesterDao;
import model.Semester;
import model.SemesterType;
import util.HtmlUtil;
import util.NotificationUtil;

@WebServlet(name = "SemestersController", urlPatterns = "/admin-semesters")
public class SemestersController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		super.service(req, resp);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("create") != null) {

			renderCreate(request, response);

		} else if (request.getParameter("edit") != null) {

			renderEdit(request, response);

		} else {

			renderIndex(request, response);

		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("update") != null) {

			doPut(request, response);

		} else if (request.getParameter("delete") != null) {

			doDelete(request, response);

		} else {

			// format date
			LocalDate start = LocalDate.parse(request.getParameter("start"), DateTimeFormatter.ISO_DATE);
			LocalDate end = LocalDate.parse(request.getParameter("end"), DateTimeFormatter.ISO_DATE);
			SemesterType type = SemesterType.valueOf(request.getParameter("type"));
			String name = type.getName();

			// create a new semester
			Semester semester = new Semester(name, type, start, end);

			// persist semester
			SemesterDao semesterDao = new SemesterDao();
			semesterDao.save(semester);

			request.setAttribute("success", "Semester created successfully");
			doGet(request, response);

		}

	}

	private void renderIndex(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		SemesterDao semesterDao = new SemesterDao();
		List<Semester> semesterList = semesterDao.getAll();

		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Semesters"));

		// Session flash notification - if any
		if (request.getAttribute("success") != null) {
			out.println(HtmlUtil.getNotificationDiv((String) request.getAttribute("success"),
					NotificationUtil.TYPE_SUCCESS));
		}

		// OUPUT THE CONTENT
		// Render create button
		out.println(HtmlUtil.getCreateButton("/admin-semesters?create=1", "New Semester"));

		String[] headers = { "Semester name", "Start date", "End date" };
		out.println(HtmlUtil.getTableHeader(headers));

		for (Semester semester : semesterList) {

			String[] tableData = { semester.getName(), HtmlUtil.formatDate(semester.getStartDate()),
					HtmlUtil.formatDate(semester.getEndDate()) };
			String editUrl = "/admin-semesters?edit=1&id=" + semester.getId();
			String deleteUrl = "/admin-semesters?delete=1&id=" + semester.getId();

			out.print(HtmlUtil.getTableRow(tableData, editUrl, deleteUrl));
		}

		out.println(HtmlUtil.getTableFooter());

		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderCreate(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Semesters"));

		// OUPUT THE CONTENT
		// Render create au form
		String formHeader = HtmlUtil.getFormHeader("Add New Semester", "/admin-semesters");
		out.println(formHeader);

		// Render form inputs
		out.println(HtmlUtil.getFormSelect("Semester name:", "type", SemesterType.toStringArray(), null));
		out.println(HtmlUtil.getFormInput("date", "Start date:", "start", null));
		out.println(HtmlUtil.getFormInput("date", "End date:", "end", null));
		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Create"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderEdit(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Find the au
		try {
			SemesterDao semesterDao = new SemesterDao();
			Semester semester = semesterDao.getById(Integer.parseInt(request.getParameter("id")));

			if (semester == null) {
				response.sendRedirect("/error?404=true");
				return;
			}

			// Render page header(skeleton)
			out.println(HtmlUtil.getHeader(request));

			// Render page title
			out.println(HtmlUtil.getPageTitle());

			// Render page subtitle
			out.println(HtmlUtil.getPageSubtitle("Semesters"));

			// OUPUT THE CONTENT
			// Render create au form
			String formHeader = HtmlUtil.getFormHeader("Edit Semester", "/admin-semesters?update=1&id=" + semester.getId());
			out.println(formHeader);

			// Render form inputs
			out.println(HtmlUtil.getFormSelect("Semester name:", "type", SemesterType.toStringArray(),
					semester.getType().name()));
			out.println(HtmlUtil.getFormInput("date", "Start date:", "start", semester.getStartDate().toString()));
			out.println(HtmlUtil.getFormInput("date", "End date:", "end", semester.getEndDate().toString()));
			// Render form submit button
			out.println(HtmlUtil.getFormSubmitButton("Update"));

			out.println(HtmlUtil.getFormFooter());

			// Render page footer
			out.println(HtmlUtil.getFooter());

		} catch (NumberFormatException e) {
			response.sendRedirect("error?500=true");
		}finally {
			out.close();
		}

	}

	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the semester
		SemesterDao semesterDao = new SemesterDao();
		Semester semester = semesterDao.getById(Integer.parseInt(request.getParameter("id")));

		if (semester == null) {
			response.sendRedirect("/error?404=true");
			return;
		}

		// Update the semester
		// format date
		LocalDate start = LocalDate.parse(request.getParameter("start"), DateTimeFormatter.ISO_DATE);
		LocalDate end = LocalDate.parse(request.getParameter("end"), DateTimeFormatter.ISO_DATE);
		SemesterType type = SemesterType.valueOf(request.getParameter("type"));
		String name = type.getName();

		semester.setName(name);
		semester.setType(type);
		semester.setStartDate(start);
		semester.setEndDate(end);

		semesterDao.save(semester);

		request.setAttribute("success", "semester updated successfully");
		doGet(request, response);

	}

	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the semester
		SemesterDao semesterDao = new SemesterDao();
		Semester semester = semesterDao.getById(Integer.parseInt(request.getParameter("id")));

		if (semester == null) {
			response.sendRedirect("/error?404=true");
			return;
		}

		semesterDao.delete(semester.getId());

		request.setAttribute("success", "Semester deleted successfully");
		doGet(request, response);

	}

}
