package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AUDao;
import model.AcademicUnit;
import model.Department;
import model.Faculty;
import model.Program;
import util.HtmlUtil;
import util.NotificationUtil;

@WebServlet(name = "AUController", urlPatterns = "/admin-au")
public class AUController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		super.service(req, resp);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("create") != null) {

			renderCreate(request, response);

		} else if (request.getParameter("edit") != null) {

			renderEdit(request, response);

		} else {

			renderIndex(request, response);

		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getParameter("update") != null) {

			doPut(request, response);

		} else if (request.getParameter("delete") != null) {

			doDelete(request, response);

		} else {

			// create a new AcademicUnit
			AcademicUnit au = new AcademicUnit();

			au.setCode(request.getParameter("code"));
			au.setProgram(Program.valueOf(request.getParameter("program")));
			au.setFaculty(Faculty.valueOf(request.getParameter("faculty")));
			au.setDepartment(Department.valueOf(request.getParameter("department")));
			au.setName(
					au.getProgram().getName() + " " + au.getFaculty().getName() + " " + au.getDepartment().getName());

			// persist AU
			AUDao auDao = new AUDao();
			auDao.save(au);

			request.setAttribute("success", "Academic unit created successfully");
			doGet(request, response);
		}
	}

	private void renderIndex(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		AUDao auDao = new AUDao();
		List<AcademicUnit> auList = auDao.getAll();

		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Academic Units"));

		// Session flash notification - if any
		if (request.getAttribute("success") != null) {
			out.println(HtmlUtil.getNotificationDiv((String) request.getAttribute("success"),
					NotificationUtil.TYPE_SUCCESS));
		}

		// OUPUT THE CONTENT
		// Render create button
		out.println(HtmlUtil.getCreateButton("/admin-au?create=1", "New Academic unit"));

		String[] headers = { "AU code", "Programme", "Faculty", "Department" };
		out.println(HtmlUtil.getTableHeader(headers));

		for (AcademicUnit au : auList) {

			String[] tableData = { au.getCode(), au.getProgram().getName(), au.getFaculty().getName(),
					au.getDepartment().getName() };
			String editUrl = "/admin-au?edit=1&id=" + au.getId();
			String deleteUrl = "/admin-au?delete=1&id=" + au.getId();

			out.print(HtmlUtil.getTableRow(tableData, editUrl, deleteUrl));
		}

		out.println(HtmlUtil.getTableFooter());

		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderCreate(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Render page header(skeleton)
		out.println(HtmlUtil.getHeader(request));

		// Render page title
		out.println(HtmlUtil.getPageTitle());

		// Render page subtitle
		out.println(HtmlUtil.getPageSubtitle("Academic Units"));

		// OUPUT THE CONTENT
		// Render create au form
		String formHeader = HtmlUtil.getFormHeader("Add New Academic Unit", "/admin-au");
		out.println(formHeader);

		// Render form inputs
		out.println(HtmlUtil.getFormInput("text", "AU Code:", "code", null));
		out.println(HtmlUtil.getFormSelect("Programme:", "program", Program.toStringArray(), null));
		out.println(HtmlUtil.getFormSelect("Faculty:", "faculty", Faculty.toStringArray(), ""));
		out.println(HtmlUtil.getFormSelect("Department:", "department", Department.toStringArray(), "  "));
		// Render form submit button
		out.println(HtmlUtil.getFormSubmitButton("Create"));

		out.println(HtmlUtil.getFormFooter());

		// Render page footer
		out.println(HtmlUtil.getFooter());

		out.close();

	}

	private void renderEdit(HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Find the au
		try {
			AUDao auDao = new AUDao();
			AcademicUnit au = auDao.getById(Integer.parseInt(request.getParameter("id")));

			if (au == null) {
				response.sendRedirect("/error?404=true");
				return;
			}

			// Render page header(skeleton)
			out.println(HtmlUtil.getHeader(request));

			// Render page title
			out.println(HtmlUtil.getPageTitle());

			// Render page subtitle
			out.println(HtmlUtil.getPageSubtitle("Academic Units"));

			// OUPUT THE CONTENT
			// Render create au form
			String formHeader = HtmlUtil.getFormHeader("Edit Academic Unit", "/admin-au?update=1&id=" + au.getId());
			out.println(formHeader);

			// Render form inputs
			out.println(HtmlUtil.getFormInput("text", "AU Code:", "code", au.getCode()));
			out.println(
					HtmlUtil.getFormSelect("Programme:", "program", Program.toStringArray(), au.getProgram().name()));
			out.println(HtmlUtil.getFormSelect("Faculty:", "faculty", Faculty.toStringArray(), au.getFaculty().name()));
			out.println(HtmlUtil.getFormSelect("Department:", "department", Department.toStringArray(),
					au.getDepartment().name()));
			// Render form submit button
			out.println(HtmlUtil.getFormSubmitButton("Update"));

			out.println(HtmlUtil.getFormFooter());

			// Render page footer
			out.println(HtmlUtil.getFooter());

		} catch (NumberFormatException e) {
			response.sendRedirect("/error?500=true");
			return;
		} catch (IOException e) {
			response.sendRedirect("/error?500=true");
			return;
		} finally {
			out.close();
		}
	}
	

	protected void doPut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the au
		AUDao auDao = new AUDao();
		AcademicUnit au = auDao.getById(Integer.parseInt(request.getParameter("id")));

		if (au == null) {
			response.sendRedirect("/error?404=true");
			return;
		}

		// Update the au
		au.setCode(request.getParameter("code"));
		au.setProgram(Program.valueOf(request.getParameter("program")));
		au.setFaculty(Faculty.valueOf(request.getParameter("faculty")));
		au.setDepartment(Department.valueOf(request.getParameter("department")));

		auDao.save(au);

		request.setAttribute("success", "Academic unit updated successfully");
		doGet(request, response);

	}

	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Find the au
		AUDao auDao = new AUDao();
		AcademicUnit au = auDao.getById(Integer.parseInt(request.getParameter("id")));

		if (au == null) {
			response.sendRedirect("/error?404=true");
			return;
		}

		auDao.delete(au.getId());

		request.setAttribute("success", "Academic unit deleted successfully");
		doGet(request, response);

	}

}
