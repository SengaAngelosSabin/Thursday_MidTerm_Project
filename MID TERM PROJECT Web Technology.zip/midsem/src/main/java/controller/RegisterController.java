package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import auth.Auth;
import dao.UserDao;
import model.User;
import util.HtmlUtil;

@WebServlet(name = "RegisterController", urlPatterns = "/register")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		out.println(HtmlUtil.getRegisterHeader());

		if (request.getAttribute("errors") != null) {
			out.println(HtmlUtil.getValidationErrorDiv((List<String>) request.getAttribute("errors")));
		}

		out.println(HtmlUtil.getRegisterFooter());
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 1.validate
		UserDao userDao = new UserDao();
		List<String> errors = validateUserInput(request, userDao);

		// 3.if validation errors,
		if (errors.size() > 0) {
			request.setAttribute("errors", errors);
			doGet(request, response);
			return;
		}

		// 4.else, create the user
		User user = new User(request.getParameter("email"), request.getParameter("password"),
				request.getParameter("role"));
		userDao.save(user);

		// 5.log them in
		Auth.login(user, request);
		Auth.redirect(user, request, response);
//		response.sendRedirect("/");
		
	}

	private List<String> validateUserInput(HttpServletRequest request, UserDao userDao) {

		List<String> errors = new ArrayList<>();

		if (!request.getParameter("password").equals(request.getParameter("passwordConfirm"))) {

			errors.add("Password and Confirm password must be the same");
		}

		if (userDao.getByEmail(request.getParameter("email")) != null) {

			errors.add("Email has already been taken");
		}
		return errors;
	}

}
