package auth;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.User;

public class Auth{
	
	

	public static User user(HttpServletRequest request) {

		HttpSession session = request.getSession();
		User sessionUser = (User) session.getAttribute("user");
		
		return sessionUser;
	}

	
	public static void login(User user, HttpServletRequest request) {

		HttpSession session = request.getSession();
		User sessionUser = (User) session.getAttribute("user");

		if (sessionUser == null) {
			session.setAttribute("user", user);
			session.setMaxInactiveInterval(60);
//			session.setMaxInactiveInterval(-1);
		}
	}

	public static void logout(HttpServletRequest request) {

		HttpSession session = request.getSession();
		User sessionUser = (User) session.getAttribute("user");

		if (sessionUser != null) {
			session.removeAttribute("user");
			session.invalidate();
		}
	}
	

	public static boolean check(HttpServletRequest request) {

		HttpSession session = request.getSession();
		User sessionUser = (User) session.getAttribute("user");

		return sessionUser != null;
	}
	

	public static boolean guard(String role, HttpServletRequest request) {
		
		User sessionUser = Auth.user(request);

		return (sessionUser != null) && sessionUser.getRole().equals(role);
	}
	
	
	public static void redirect(User user, HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		if(user.getRole().equals("admin")) {
			
			response.sendRedirect("/admin-home");
			
		}else {
			
			response.sendRedirect("/");
		}
		
	}
	

}
