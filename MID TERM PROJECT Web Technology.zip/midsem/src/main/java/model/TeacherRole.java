package model;

public enum TeacherRole {

	TUTOR("Tutor"), ASSISTANT("Assistant");

	private String name;

	TeacherRole(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public static String[] toStringArray() {

		String[] list = new String[TeacherRole.values().length];

		for (int i = 0; i < TeacherRole.values().length; i++) {

			list[i] = TeacherRole.values()[i].name();
		}

		return list;
	}
}
