package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "registrations")
public class Registration {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Temporal(TemporalType.DATE)
	private LocalDate registrationDate;

	@ManyToOne()
	@JoinColumn(name = "student_id")
	private Student student;

	@ManyToOne()
	@JoinColumn(name = "semester_id")
	private Semester semester;

	@ManyToMany(fetch = FetchType.EAGER, cascade = { CascadeType.PERSIST, CascadeType.DETACH, CascadeType.MERGE,
			CascadeType.REFRESH })
	@JoinTable(name = "course_registration", joinColumns = @JoinColumn(name = "registration_id"), inverseJoinColumns = @JoinColumn(name = "course_id"))
	private List<Course> courses;

//	@ManyToOne()
//	@JoinColumn(name = "academicUnit_id")
//	private AcademicUnit academicUnit;

	public Registration() {
	}

	public Registration(LocalDate registrationDate) {
		super();
		this.registrationDate = registrationDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDate registrationDate) {
		this.registrationDate = registrationDate;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Semester getSemester() {
		return semester;
	}

	public void setSemester(Semester semester) {
		this.semester = semester;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

//	public AcademicUnit getAcademicUnit() {
//		return academicUnit;
//	}
//
//	public void setAcademicUnit(AcademicUnit academicUnit) {
//		this.academicUnit = academicUnit;
//	}

	public void addCourse(Course course) {

		if (courses == null) {
			courses = new ArrayList<>();
		}

		courses.add(course);
	}

	public String[] getStudentCourseIds() {

		String[] ids = new String[this.courses.size()];

		for (int i = 0; i < this.courses.size(); i++) {

			ids[i] = String.valueOf(this.courses.get(i).getId());
		}

		return ids;
	}

	@Override
	public String toString() {
		return "Registration [id=" + id + ", registrationDate=" + registrationDate + ", student=" + student
				+ ", semester=" + semester + ", courses=" + courses + "]";
	}

}
