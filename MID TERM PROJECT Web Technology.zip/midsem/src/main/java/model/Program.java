package model;

public enum Program {

	UNDERGRADUATE("Undergraduate"),
	MASTERS("Masters");
	
	private String name;
	
    Program(String name) {
        this.name = name;
    }
 
    public String getName() {
        return name;
    }
    
    public static String[] toStringArray() {
    	
    	String[] list = new String[Program.values().length];
    	
    	for(int i = 0; i < Program.values().length; i++) {
    		
    		list[i] = Program.values()[i].name();
    	}
    	
    	return list;
    }
}
