package model;

public enum SemesterType {

	SEMESTER_ONE("Semester One"), SEMESTER_TWO("Semester Two"), SUMMER("Summer Semester");

	private String name;

	SemesterType(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public static String[] toStringArray() {

		String[] list = new String[SemesterType.values().length];

		for (int i = 0; i < SemesterType.values().length; i++) {

			list[i] = SemesterType.values()[i].name();
		}

		return list;
	}
}
