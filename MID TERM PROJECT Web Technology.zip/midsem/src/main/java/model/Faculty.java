package model;

public enum Faculty {

	IT("Information Technology"), BUSINESS_ADMINISTRATION("Business Administration"), EDUCATION("Education"),
	MBA("Masters of Business Administration"), BIG_DATA("Masters of Science in Big Data Analytics"),
	MA_EDUCATION("Masters of Arts in Education");

	private String name;

	Faculty(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public static String[] toStringArray() {

		String[] list = new String[Faculty.values().length];
		
		for (int i = 0; i < Faculty.values().length; i++) {
			
			list[i] = Faculty.values()[i].name();
		}

		return list;
	}
}
