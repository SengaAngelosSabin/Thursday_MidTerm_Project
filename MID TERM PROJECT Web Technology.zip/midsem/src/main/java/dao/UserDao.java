package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import model.User;
import util.HibernateUtil;

public class UserDao {

	public void save(User user) {
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the user
			session.saveOrUpdate(user);

			// commit transaction
			transaction.commit();

		} catch (Exception e) {
			System.out.println(e);

			if (transaction != null) {
				transaction.rollback();
			}
			System.out.println("500 page");
		}
	}

	public List<User> getAll() {

		List<User> users = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			users = session.createQuery("from User", User.class).list();

		} catch (Exception e) {
			System.out.println("500 page");
		}

		return users;
	}

	public User getById(int id) {

		User user = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			user = session.get(User.class, id);

		} catch (Exception e) {
			System.out.println("500 page");
		}

		return user;
	}

	public User getByEmail(String email) {

		User user = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			Query<User> query = session.createQuery("from User u where u.email = :data", User.class);
			query.setParameter("data", email);
			user = (User) query.getSingleResult();

		} catch (Exception e) {
			System.out.println("500 page");
		}

		return user;
	}

	public void delete(int id) {

		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			User user = session.get(User.class, id);

			if (user != null) {
				session.remove(user);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			System.out.println("500 page");
		}
	}

}
