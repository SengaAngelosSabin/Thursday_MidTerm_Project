package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.AcademicUnit;
import util.HibernateUtil;

public class AUDao {

	public void save(AcademicUnit academicUnit) {
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the au
			session.saveOrUpdate(academicUnit);

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	

	public List<AcademicUnit> getAll() {

		List<AcademicUnit> academicUnits = null;
		
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			academicUnits = session.createQuery("from AcademicUnit", AcademicUnit.class).list();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return academicUnits;
	}

	
	public AcademicUnit getById(int id) {

		AcademicUnit academicUnit = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			academicUnit = session.get(AcademicUnit.class, id);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return academicUnit;
	}
	
	
	public void delete(int id) {
		
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			AcademicUnit academicUnit = session.get(AcademicUnit.class, id);
			
			if(academicUnit != null) {
				session.remove(academicUnit);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
		
}
