package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import model.Student;
import util.HibernateUtil;

public class StudentDao {

	public void save(Student student) {
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the student
			session.saveOrUpdate(student);

			// commit transaction
			transaction.commit();

		} catch (Exception e) {
			System.out.println(e);

			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	public List<Student> getAll() {

		List<Student> students = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			students = session.createQuery("from Student", Student.class).list();

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return students;
	}

	public Student getById(int id) {

		Student student = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			student = session.get(Student.class, id);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return student;
	}

	public Student getByRegNo(String regNo) {

		Student student = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			
			Query<Student> query = session.createQuery("from Student s where s.regNo = :data", Student.class);
			query.setParameter("data", regNo);
			student = (Student) query.getSingleResult();

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return student;
	}
	
	
	public void delete(int id) {

		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			Student student = session.get(Student.class, id);

			if (student != null) {
				session.remove(student);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	
	
}
