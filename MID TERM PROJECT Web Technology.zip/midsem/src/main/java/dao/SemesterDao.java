package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Semester;
import util.HibernateUtil;

public class SemesterDao {

	public void save(Semester semester) {
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the student
			session.saveOrUpdate(semester);

			// commit transaction
			transaction.commit();

		} catch (Exception e) {
			System.out.println(e);
			
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	public List<Semester> getAll() {

		List<Semester> semesters = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			semesters = session.createQuery("from Semester", Semester.class).list();

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return semesters;
	}
	
	public Semester getById(int id) {

		Semester semester = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			semester = session.get(Semester.class, id);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return semester;
	}
	
	
	public void delete(int id) {
		
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			Semester semester = session.get(Semester.class, id);
			
			if(semester != null) {
				session.remove(semester);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	
}
