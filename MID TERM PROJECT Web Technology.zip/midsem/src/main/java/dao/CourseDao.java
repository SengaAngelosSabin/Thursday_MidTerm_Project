package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Course;
import util.HibernateUtil;

public class CourseDao {

	public void save(Course course) {
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the au
			session.saveOrUpdate(course);

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	public List<Course> getAll() {

		List<Course> courses = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			courses = session.createQuery("from Course", Course.class).list();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return courses;
	}

	public Course getById(int id) {

		Course course = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			course = session.get(Course.class, id);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return course;
	}

	public void delete(int id) {

		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			Course course = session.get(Course.class, id);

			if (course != null) {
				session.remove(course);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

}
