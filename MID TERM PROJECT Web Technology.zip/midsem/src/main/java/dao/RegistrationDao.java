package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Registration;
import util.HibernateUtil;

public class RegistrationDao {

	public void save(Registration registration) {
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the au
			session.saveOrUpdate(registration);

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	public List<Registration> getAll() {

		List<Registration> registrations = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			registrations = session.createQuery("from Registration", Registration.class).list();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return registrations;
	}

	public Registration getById(int id) {

		Registration registration = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			registration = session.get(Registration.class, id);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return registration;
	}

	public void delete(int id) {

		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			Registration registration = session.get(Registration.class, id);

			if (registration != null) {
				session.remove(registration);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
}
