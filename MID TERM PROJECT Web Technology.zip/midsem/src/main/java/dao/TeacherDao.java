package dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.Teacher;
import util.HibernateUtil;

public class TeacherDao {

	public void save(Teacher teacher) {
		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the student
			session.saveOrUpdate(teacher);

			// commit transaction
			transaction.commit();

		} catch (Exception e) {
			System.out.println(e);
			
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	public List<Teacher> getAll() {

		List<Teacher> teachers = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			teachers = session.createQuery("from Teacher", Teacher.class).list();

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return teachers;
	}
	
	
	public Teacher getById(int id) {

		Teacher teacher = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {

			teacher = session.get(Teacher.class, id);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return teacher;
	}
	
	
	public void delete(int id) {

		Transaction transaction = null;

		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			Teacher teacher = session.get(Teacher.class, id);

			if (teacher != null) {
				session.remove(teacher);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			System.out.println(e);
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	
}
