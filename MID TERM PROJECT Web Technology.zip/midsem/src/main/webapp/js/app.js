const dropdownLevelOneMenuItems =
  document.querySelectorAll(".dropdown-level-1");

dropdownLevelOneMenuItems.forEach((menuItem) =>
  menuItem.addEventListener("mouseenter", handleEnter)
);
dropdownLevelOneMenuItems.forEach((menuItem) =>
  menuItem.addEventListener("mouseleave", handleLeave)
);

function handleEnter(e) {
  const subMenu = this.querySelector("div");
  subMenu.classList.toggle("hidden");
}

function handleLeave(e) {
  const subMenu = this.querySelector("div");
  subMenu.classList.toggle("hidden");
}

document.querySelectorAll("img").forEach(function(image){
	image.src = image.src.replace("8080", "5500");
});