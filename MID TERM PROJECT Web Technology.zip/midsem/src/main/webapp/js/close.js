
const deleteIcon = document.querySelector(".delete");
if(deleteIcon){
	deleteIcon.addEventListener("click", function(){
			deleteIcon.parentNode.style.display = "none";	
		}
	);
}

setTimeout(function () {
	const deleteIcon = document.querySelector(".delete");
	if(deleteIcon.parentNode.style.display != "none"){
    	deleteIcon.parentNode.style.display = "none";
    }
},5000);