package midsem;

import util.HibernateUtil;

public class AppTest {

	public static void main(String[] args) {

		System.out.println("TESTING APP ...");

		System.out.println("CREATING DATABASE TABLES ...");
		HibernateUtil.getSessionFactory();
		
		System.out.println("DONE!");

	}

}
